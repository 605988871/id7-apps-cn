'use strict';
/*
 * units.js - cn_iteriodev_cardash 1.5.0 (user 2026-11-23: "follow the car's units for everything"): the units the car is set
 * to - Vehicle (0xB510) statusNewCurrentUnitsStatusExt, the struct BMW's own screens and the cluster use - and the
 * conversions from the app's own values. Inside the app everything stays metric (°C, km/h, km, l, l/100 km, l/h, bar,
 * kW, Nm; trips.json and settings.json too): only what is shown is converted. Pure, Node 8. Self-check: node units.js
 *
 *   decode(status, prev)  the struct (enum names; numbers on some head units) -> { temp, speed, cons, fuel, press, power,
 *                         torque }; a field without a valid unit keeps prev's (DEFAULT before the car answered)
 *   make(set)             -> u, for a set from decode (undefined: DEFAULT):
 *     u.v(kind, x)        the value shown (NaN without one)       u.back(kind, y)   a shown value back to the app's own
 *     u.l(kind)           its label ('°F', 'psi', ...)            u.d(kind, d)      the decimals for a metric value shown with d
 *     u.n(kind, x, d)     the number text ('--' without)          u.t(kind, x, d)   number and label: '12.3 mpg'
 *     u.k(label)          the kind of a metric label (Details' values): null = shown as it is
 *   kinds: temp, dtemp (a temperature difference), speed, dist, vol, flow (l/h), cons (l/100 km), press (bar), mbar,
 *          power (kW), torque (Nm), perVol (a price per litre: per gallon with gallons)
 * Power: kW, or hp when the car says PS (owner rule 2026-11-22: never PS). The car has no distance unit of its own: its
 * speed unit's (mph = miles). Gallons: the UK or US one, as the car says, both shown "gal".
 */
const isNum = (x) => typeof x === 'number' && isFinite(x);
const DEFAULT = { temp: 'c', speed: 'kmh', cons: 'l100', fuel: 'l', press: 'bar', power: 'hp', torque: 'nm' };   // Car Data before 1.5.0
// field of the struct, its enumerators (UnitOfMeasurement*: VehicleTypes) -> ours
const ENUMS = {
    temp: ['unitOfMeasurementTemperature', { C: 'c', F: 'f', 1: 'c', 2: 'f' }],
    speed: ['unitOfMeasurementSpeedometerDigital', { KILOMETER: 'kmh', MEILEN: 'mph', 1: 'kmh', 2: 'mph' }],
    cons: ['unitOfMeasurementConsumption', { L_S_100KM: 'l100', MPG__UK: 'mpgUK', MPG__US: 'mpgUS', KM_S_L: 'kml', 1: 'l100', 2: 'mpgUK', 3: 'mpgUS', 4: 'kml' }],
    fuel: ['unitOfMeasurementFuel', { LITER: 'l', GALONEN__UK: 'galUK', GALONEN__US: 'galUS', 1: 'l', 2: 'galUK', 3: 'galUS' }],
    press: ['unitOfMeasurementAirPressure', { BAR: 'bar', KPA: 'kpa', PSI: 'psi', 1: 'bar', 2: 'kpa', 3: 'psi' }],
    power: ['unitOfMeasurementPowerSportMode', { KW: 'kw', PS: 'hp', 1: 'kw', 2: 'hp' }],
    torque: ['unitOfMeasurementTorqueSportMode', { NM: 'nm', LB_MINUS_FT: 'lbft', KGM: 'kgm', 1: 'nm', 2: 'lbft', 3: 'kgm' }],
};
function decode(x, prev) {
    const out = Object.assign({}, DEFAULT, prev);
    if (x && typeof x === 'object') {
        Object.keys(ENUMS).forEach((k) => {
            const [field, map] = ENUMS[k], v = x[field];
            if (v !== undefined && v !== null && Object.prototype.hasOwnProperty.call(map, v)) out[k] = map[v];
        });
    }
    return out;
}

const MI = 1.609344, GAL = { galUK: 4.54609, galUS: 3.785411784 }, PSI = 14.5037738, HP = 1.34102209, LBFT = 0.737562149, KGM = 0.101971621;
const lin = (k, o) => [(x) => x * k + (o || 0), (y) => (y - (o || 0)) / k];
const inv = (k) => [(x) => (x > 0 ? k / x : NaN), (y) => (y > 0 ? k / y : NaN)];    // l/100 km <-> mpg, km/l
// kind -> [the set's group, { unit: [label, [to, back], decimals +/-] }]
const TABLE = {
    temp: ['temp', { c: ['°C', lin(1), 0], f: ['°F', lin(1.8, 32), 0] }],
    dtemp: ['temp', { c: ['°C', lin(1), 0], f: ['°F', lin(1.8), 0] }],
    speed: ['speed', { kmh: ['km/h', lin(1), 0], mph: ['mph', lin(1 / MI), 0] }],
    dist: ['speed', { kmh: ['km', lin(1), 0], mph: ['mi', lin(1 / MI), 0] }],
    vol: ['fuel', { l: ['l', lin(1), 0], galUK: ['gal', lin(1 / GAL.galUK), 0], galUS: ['gal', lin(1 / GAL.galUS), 0] }],
    flow: ['fuel', { l: ['l/h', lin(1), 0], galUK: ['gal/h', lin(1 / GAL.galUK), 0], galUS: ['gal/h', lin(1 / GAL.galUS), 0] }],
    cons: ['cons', { l100: ['l/100 km', lin(1), 0], mpgUK: ['mpg', inv(282.480936), 0], mpgUS: ['mpg', inv(235.214583), 0], kml: ['km/l', inv(100), 0] }],
    press: ['press', { bar: ['bar', lin(1), 0], kpa: ['kPa', lin(100), -2], psi: ['psi', lin(PSI), -1] }],
    mbar: ['press', { bar: ['mbar', lin(1), 0], kpa: ['kPa', lin(0.1), 1], psi: ['psi', lin(PSI / 1000), 2] }],
    power: ['power', { kw: ['kW', lin(1), 0], hp: ['hp', lin(HP), 0] }],
    torque: ['torque', { nm: ['Nm', lin(1), 0], lbft: ['lb-ft', lin(LBFT), 0], kgm: ['kgm', lin(KGM), 1] }],
    perVol: ['fuel', { l: ['l', lin(1), 0], galUK: ['gal', lin(GAL.galUK), 0], galUS: ['gal', lin(GAL.galUS), 0] }],
};
// Details' values: their metric label -> kind (hPa = mbar)
const LABELS = { '°C': 'temp', 'km/h': 'speed', km: 'dist', l: 'vol', 'l/h': 'flow', 'l/100 km': 'cons', bar: 'press', mbar: 'mbar',
    hPa: 'mbar', kW: 'power', Nm: 'torque' };

function make(set) {
    const s = Object.assign({}, DEFAULT, set);
    const row = (kind) => { const [g, units] = TABLE[kind]; return units[s[g]] || units[DEFAULT[g]]; };
    const u = {
        set: s,
        v: (kind, x) => (isNum(x) ? row(kind)[1][0](x) : NaN),
        back: (kind, y) => (isNum(y) ? row(kind)[1][1](y) : NaN),
        l: (kind) => row(kind)[0],
        d: (kind, d) => Math.max(0, d + row(kind)[2]),
        n: (kind, x, d) => { const v = u.v(kind, x); return isNum(v) ? v.toFixed(u.d(kind, d)).replace(/^-(0(\.0+)?)$/, '$1') : '--'; },
        t: (kind, x, d) => { const n = u.n(kind, x, d); return n === '--' ? n : `${n} ${u.l(kind)}`; },
        k: (label) => LABELS[label] || null,
    };
    return u;
}

module.exports = { decode, make, DEFAULT };

if (require.main === module) {
    const assert = require('assert');
    const m = make();
    assert.deepStrictEqual([m.t('temp', 90, 0), m.t('press', 1.234, 2), m.t('power', 100, 0), m.t('torque', 400, 0), m.t('cons', 8.5, 1),
        m.t('speed', 100, 0), m.t('vol', 50, 1), m.t('mbar', 44, 0), m.n('temp', undefined, 0)],
    ['90 °C', '1.23 bar', '134 hp', '400 Nm', '8.5 l/100 km', '100 km/h', '50.0 l', '44 mbar', '--'], 'before the car says: as Car Data always showed');
    // a US car: the names as the ID8 SDK hands them
    const us = decode({ language: 'ENGLISCH__US', unitOfMeasurementTemperature: 'F', unitOfMeasurementSpeedometerDigital: 'MEILEN',
        unitOfMeasurementConsumption: 'MPG__US', unitOfMeasurementFuel: 'GALONEN__US', unitOfMeasurementAirPressure: 'PSI',
        unitOfMeasurementPowerSportMode: 'PS', unitOfMeasurementTorqueSportMode: 'LB_MINUS_FT' });
    const u = make(us);
    assert.deepStrictEqual([u.t('temp', 90, 0), u.t('dtemp', 10, 0), u.t('speed', 100, 0), u.t('dist', 10, 1), u.t('vol', 3.785411784, 2),
        u.t('flow', 7.57, 1), u.t('cons', 10, 1), u.t('press', 1, 2), u.t('mbar', 100, 0), u.t('power', 100, 0), u.t('torque', 400, 0)],
    ['194 °F', '18 °F', '62 mph', '6.2 mi', '1.00 gal', '2.0 gal/h', '23.5 mpg', '14.5 psi', '1.45 psi', '134 hp', '295 lb-ft']);
    assert.strictEqual(+u.v('perVol', 1).toFixed(3), 3.785, 'a price per litre: per US gallon');
    assert.strictEqual(+u.back('temp', 212).toFixed(3), 100);
    assert.strictEqual(+u.back('cons', 23.5214583).toFixed(3), 10);
    assert.strictEqual(+u.back('press', 14.5037738).toFixed(3), 1);
    // numbers (other head units), kW, kgm, kPa, UK, km/l; an invalid field keeps the last
    const n = decode({ unitOfMeasurementTemperature: 3, unitOfMeasurementPowerSportMode: 1, unitOfMeasurementTorqueSportMode: 3,
        unitOfMeasurementAirPressure: 2, unitOfMeasurementConsumption: 2, unitOfMeasurementFuel: 2 }, { temp: 'f' });
    const k = make(n);
    assert.deepStrictEqual([k.set.temp, k.t('power', 100, 0), k.t('torque', 400, 0), k.t('press', 1.5, 2), k.t('mbar', 44, 0),
        k.t('cons', 8, 1), k.t('vol', 4.54609, 1), make({ cons: 'kml' }).t('cons', 5, 1)],
    ['f', '100 kW', '40.8 kgm', '150 kPa', '4.4 kPa', '35.3 mpg', '1.0 gal', '20.0 km/l']);
    assert.deepStrictEqual([k.k('°C'), k.k('hPa'), k.k('rpm'), k.k('%')], ['temp', 'mbar', null, null]);
    assert.strictEqual(make({ cons: 'mpgUS' }).n('cons', 0, 1), '--', 'standing (0 l/100 km): no mpg');
    console.log('units: ok');
}
